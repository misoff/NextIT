package me.nextit.demo;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;


public class DBConnection {

    private final String urlDB = "jdbc:mysql://localhost:3306/nextit_db?useSSL=false";
    private final String user = "nextit_db";
    private final String pass = "YbsXijoscABIAd1W";


    private Connection con;
    private String aesKey = "mGy4L1e5Rq04875rDg4Qo487mAe54Ehd";

    public DBConnection(){
        //Connection con = null;
    }

    public void addAddress(int id, School school, String street, String village, String zip)  {
        String query = "INSERT INTO address(id, school_id, street, village, zip)"
                + "values(?, ?, ?, ?, ?)";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, id);
            preparedStmt.setInt(2, school.getId());
            preparedStmt.setString(3, street);
            preparedStmt.setString(4, village);
            preparedStmt.setString(5, zip);
            preparedStmt.execute();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean addAddress(Address adress)  {
        boolean isCorrectCreated = false;
        String query = "INSERT INTO address(id, school_id, street, village, zip)"
                + "values(?, ?, ?, ?, ?)";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, adress.getId());
            preparedStmt.setInt(2, adress.getSchool().getId());
            preparedStmt.setString(3, adress.getStreet());
            preparedStmt.setString(4, adress.getVillage());
            preparedStmt.setString(5, adress.getZip());
            preparedStmt.execute();
            con.close();
            isCorrectCreated = true;
        } catch (Exception e) {
            e.printStackTrace();
            isCorrectCreated = false;
        }
        return isCorrectCreated;
    }

    public boolean addAddressSchool(Address adress)  {
        boolean isCorrectCreated = false;
        String addressQuery = "INSERT INTO address(id, school_id, street, village, zip)"
                + "values(?, ?, ?, ?, ?)";
        String schoolQuery = "INSERT INTO school(id, year, name, district, region, footprint)"
                + "values(?, ?, ?, ?, ?, ?)";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(addressQuery);
            preparedStmt.setInt(1, adress.getId());
            preparedStmt.setInt(2, adress.getSchool().getId());
            preparedStmt.setString(3, adress.getStreet());
            preparedStmt.setString(4, adress.getVillage());
            preparedStmt.setString(5, adress.getZip());
            preparedStmt.execute();

            preparedStmt = con.prepareStatement(schoolQuery);
            preparedStmt.setInt(1, adress.getSchool().getId());
            preparedStmt.setInt(2, adress.getSchool().getYear());
            preparedStmt.setString(3, adress.getSchool().getName());
            preparedStmt.setString(4, adress.getSchool().getDistrict());
            preparedStmt.setString(5, adress.getSchool().getRegion());
            preparedStmt.setBigDecimal(6, adress.getSchool().getFootprint());
            preparedStmt.execute();
            isCorrectCreated = true;
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
            isCorrectCreated = false;
        }
        return isCorrectCreated;
    }

    public void addSchool(int id, short year, String name, String district, String region, BigDecimal footprint){
        //Connection con = null;
        String query = "INSERT INTO school(id, year, name, district, region, footprint)"
                + "values(?, ?, ?, ?, ?, ?)";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, id);
            preparedStmt.setInt(2, year);
            preparedStmt.setString(3, name);
            preparedStmt.setString(4, district);
            preparedStmt.setString(5, region);
            preparedStmt.setBigDecimal(6, footprint);
            preparedStmt.execute();
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean addSchool(School school){
        boolean isCorrectCreated = false;
        String query = "INSERT INTO school(id, year, name, district, region, footprint)"
                + "values(?, ?, ?, ?, ?, ?)";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, school.getId());
            preparedStmt.setInt(2, school.getYear());
            preparedStmt.setString(3, school.getName());
            preparedStmt.setString(4, school.getDistrict());
            preparedStmt.setString(5, school.getRegion());
            preparedStmt.setBigDecimal(6, school.getFootprint());
            preparedStmt.execute();
            con.close();
            isCorrectCreated = true;
        } catch (Exception e) {
            e.printStackTrace();
            isCorrectCreated = false;
        }
        return isCorrectCreated;
    }

    public boolean updateAddress(int tempID, Address tempAddress){
        boolean isCorrectCreated = false;
        String query = "UPDATE address SET school_id = ?, street = ?, village = ?, zip = ?" +
                "WHERE id = ?";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, tempAddress.getSchool().getId());
            preparedStmt.setString(2, tempAddress.getStreet());
            preparedStmt.setString(3, tempAddress.getVillage());
            preparedStmt.setString(4, tempAddress.getZip());
            preparedStmt.setInt(5, tempID);
            preparedStmt.execute();
            con.close();
            isCorrectCreated = true;
        } catch (Exception e) {
            e.printStackTrace();
            isCorrectCreated = false;
        }
        return isCorrectCreated;
    }

    public boolean updateSchool(int tempID, School school){
        boolean isCorrectCreated = false;
        String query = "UPDATE school SET id = ?, year = ?, name = ?, district = ?, region = ?, footprint = ?" +
                "WHERE id = ?";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, school.getId());
            preparedStmt.setInt(2, school.getYear());
            preparedStmt.setString(3, school.getName());
            preparedStmt.setString(4, school.getDistrict());
            preparedStmt.setString(5, school.getRegion());
            preparedStmt.setBigDecimal(6, school.getFootprint());
            preparedStmt.setInt(7, tempID);
            preparedStmt.execute();
            con.close();
            isCorrectCreated = true;
        } catch (Exception e) {
            e.printStackTrace();
            isCorrectCreated = false;
        }
        return isCorrectCreated;
    }

    public boolean deleteSchoolByID(int id){
        boolean isCorrectRemoved = false;
        String query = "DELETE FROM school"
                + " WHERE id = ?";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, id);
            preparedStmt.execute();
            con.close();
            isCorrectRemoved = true;
        } catch (Exception e) {
            e.printStackTrace();
            isCorrectRemoved = false;
        }
        return isCorrectRemoved;
    }

    public boolean deleteAddressByID(int id){
        boolean isCorrectRemoved = false;
        String query = "DELETE FROM address"
                + " WHERE id = ?";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, id);
            preparedStmt.execute();
            con.close();
            isCorrectRemoved = true;
        } catch (Exception e) {
            e.printStackTrace();
            isCorrectRemoved = false;
        }
        return isCorrectRemoved;
    }

    public Address getAddressByID(int id){
        Address tempAddress = new Address();
        String query = "SELECT address.school_id, address.street, address.village, address.zip," +
                "school.year, school.name, school.district, school.region, school.footprint" +
                " FROM address INNER JOIN school ON address.school_id = school.id " +
                " WHERE address.id = ?";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setInt(1, id);
            ResultSet rs = preparedStmt.executeQuery();
            if(rs.next()){
                int schoolID = rs.getInt("address.school_id");
                String street = rs.getString("address.street");
                String village = rs.getString("address.village");
                String address = rs.getString("address.zip");
                short year = rs.getShort("school.year");
                String name = rs.getString("school.name");
                String district = rs.getString("school.district");
                String region = rs.getString("school.region");
                BigDecimal footprint = rs.getBigDecimal("school.footprint");

                School tempSchool = new School(schoolID, year, name, district, region, footprint);
                tempAddress = new Address(id, tempSchool, street, village, address);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tempAddress;
    }

    public ArrayList<Address> getAllAddresses(){
        ArrayList<Address> tempAddresses = new ArrayList<>();
        //Connection con = null;
        String query = "SELECT address.id, school_id, street, village, zip from address";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);
            PreparedStatement preparedStmt = con.prepareStatement(query);
            ResultSet rs = preparedStmt.executeQuery();
            while(rs.next()){
                int id = rs.getInt("address.id");
                int schoolID = rs.getInt("school_id");
                String street = rs.getString("street");
                String village = rs.getString("village");
                String address = rs.getString("zip");
                School tempSchool = new School();
                tempSchool.setId(schoolID);
                Address tempAddress = new Address(id, tempSchool, street, village, address);
                tempAddresses.add(tempAddress);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tempAddresses;
    }

    public ArrayList<Address> getAllAddressesAndSchoolsByYears(boolean isRange, int start, int end){
        return getAllByParam(isRange, start, end);
    }

    public ArrayList<Address> getAllAddressesAndSchools(){
        return getAllByParam(false, 0, 2100);
    }

    private ArrayList<Address> getAllByParam(boolean isRange, int start, int end){
        ArrayList<Address> tempAddresses = new ArrayList<>();
        //Connection con = null;
        String query = "SELECT address.id,  address.school_id, address.street, address.village, address.zip," +
                "school.year, school.name, school.district, school.region, school.footprint" +
                " FROM address INNER JOIN school ON address.school_id = school.id ";
        if(isRange){
            query = query + "WHERE school.year BETWEEN " + start + " AND " + end + " ";

        }
        query = query + " ORDER By school.year DESC";
        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);
            PreparedStatement preparedStmt = con.prepareStatement(query);
            ResultSet rs = preparedStmt.executeQuery();
            while(rs.next()){
                int id = rs.getInt("address.id");
                int schoolID = rs.getInt("address.school_id");
                String street = rs.getString("address.street");
                String village = rs.getString("address.village");
                String address = rs.getString("address.zip");
                short year = rs.getShort("school.year");
                String name = rs.getString("school.name");
                String district = rs.getString("school.district");
                String region = rs.getString("school.region");
                BigDecimal footprint = rs.getBigDecimal("school.footprint");

                School tempSchool = new School(schoolID, year, name, district, region, footprint);
                //tempSchool.setId(schoolID);
                Address tempAddress = new Address(id, tempSchool, street, village, address);
                tempAddresses.add(tempAddress);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tempAddresses;
    }

    public ArrayList<Address> getAllAddressesAndSchoolsWithWrongZip(){
        ArrayList<Address> tempAddresses = new ArrayList<>();
        //Connection con = null;
        String query = "SELECT address.id,  address.school_id, address.street, address.village, address.zip," +
                "school.year, school.name, school.district, school.region, school.footprint" +
                " FROM address INNER JOIN school ON address.school_id = school.id " +
                "WHERE address.zip LIKE '%X%'" +
                "ORDER By school.year DESC";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);
            PreparedStatement preparedStmt = con.prepareStatement(query);
            ResultSet rs = preparedStmt.executeQuery();
            while(rs.next()){
                int id = rs.getInt("address.id");
                int schoolID = rs.getInt("address.school_id");
                String street = rs.getString("address.street");
                String village = rs.getString("address.village");
                String address = rs.getString("address.zip");
                short year = rs.getShort("school.year");
                String name = rs.getString("school.name");
                String district = rs.getString("school.district");
                String region = rs.getString("school.region");
                BigDecimal footprint = rs.getBigDecimal("school.footprint");
                School tempSchool = new School(schoolID, year, name, district, region, footprint);
                Address tempAddress = new Address(id, tempSchool, street, village, address);
                tempAddresses.add(tempAddress);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tempAddresses;
    }

    public User getUser(String userName, char[] passInput){
        User tempUser = new User();

        String query = "SELECT id, credentials from users"
                + " WHERE login = ? AND pass = AES_ENCRYPT(?, ?)";

        try {
            Class.forName("org.mariadb.jdbc.Driver");
            con = DriverManager.getConnection(urlDB,user,pass);

            PreparedStatement preparedStmt = con.prepareStatement(query);
            preparedStmt.setString(1, userName);
            preparedStmt.setString(2, String.valueOf(passInput));
            preparedStmt.setString(3, aesKey);

            ResultSet rs = preparedStmt.executeQuery();
            if(rs.next()){
                int id = rs.getInt("id");
                int credentials = rs.getInt("credentials");
                tempUser.setUserName(userName);
                tempUser.setUserID(id);
                tempUser.setCredentials(credentials);
            }
            con.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return tempUser;
    }

}
