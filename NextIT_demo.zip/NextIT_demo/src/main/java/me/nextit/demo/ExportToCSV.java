package me.nextit.demo;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ExportToCSV {

    public ExportToCSV(){

    }

    public boolean execLocalExport(String pathToSave, ArrayList<Address> addresses){
        boolean isExported = false;
        PrintWriter pw = null;
        try {
            pw = new PrintWriter(new File(pathToSave + ".csv"));
            StringBuilder sb = new StringBuilder();
            sb.append("school_id;");
            sb.append("year;");
            sb.append("name;");
            sb.append("address_id;");
            sb.append("street;");
            sb.append("village;");
            sb.append("zip;");
            sb.append("district;");
            sb.append("region;");
            sb.append("footprint");
            sb.append("\n");
            for(int tempAddressPointer = 0; tempAddressPointer < addresses.size(); tempAddressPointer++){
                sb.append(addresses.get(tempAddressPointer).getSchool().getId() + ";");
                sb.append(addresses.get(tempAddressPointer).getSchool().getYear() + ";");
                sb.append(addresses.get(tempAddressPointer).getSchool().getName() + ";");
                sb.append(addresses.get(tempAddressPointer).getId() + ";");
                sb.append(addresses.get(tempAddressPointer).getStreet() + ";");
                sb.append(addresses.get(tempAddressPointer).getVillage() + ";");
                sb.append(addresses.get(tempAddressPointer).getZip() + ";");
                sb.append(addresses.get(tempAddressPointer).getSchool().getDistrict() + ";");
                sb.append(addresses.get(tempAddressPointer).getSchool().getRegion() + ";");
                sb.append(addresses.get(tempAddressPointer).getSchool().getFootprint() + ";");
                sb.append("\n");
            }
            pw.write(sb.toString());
            pw.close();
            isExported = true;
        }catch (FileNotFoundException ex) {
            Logger.getLogger(ExportToCSV.class.getName()).log(Level.SEVERE, null, ex);
            isExported = false;
        } finally {
            pw.close();
        }
        return isExported;
    }
}
