package me.nextit.demo;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Random;


public class NextITDemoGUI extends JFrame{
    private JPanel loginPanel;
    private JTextField JFieldLogin;
    private JPasswordField JPassFieldInput;
    private JButton ButtonLogin;
    private JLabel JLabelLogin;
    private JLabel JLabelPass;
    private JLabel JLabelLoginStatus;
    private JPanel mainPanel;
    private JPanel menuPanel;
    private JTabbedPane tabbedPaneMain;
    private JButton loadJSONFileButton;
    private JButton exportToCSVFileButton;
    private JTable JTableAllRecords;
    private JPanel JPanelTable;
    private JPanel JPanelInOut;
    private JTextField textFieldSchoolID;
    private JLabel JLabelSchoolID;
    private JLabel JLabelRows;
    private JTextField JTextFieldYear;
    private JTextField JTextFieldName;
    private JTextField JTextFieldAddressID;
    private JTextField JTextFieldStreet;
    private JTextField JTextFieldVillage;
    private JTextField JTextFieldZIP;
    private JTextField JTextFieldDistrict;
    private JTextField JTextFieldRegion;
    private JTextField JTextFieldFootprint;
    private JPanel JPanelInfo;
    private JButton ButtonDeleteRecord;
    private JButton ButtonUpdateRecord;
    private JButton ButtonCreateRecord;
    private JPanel JPanelCRUD;
    private JPanel JPanelSchool;
    private JPanel JPanelAddress;
    private JTextArea TextAreaInfo;
    private JButton ButtonRefreshRecords;
    private JButton ButtonLogOut;
    private JComboBox comboBoxYears;
    private JSpinner SpinnerFrom;
    private JSpinner SpinnerTo;

    private String userName;
    private int credentials = 0;
    private int userId;
    private AppCore appCore;
    private String[] tableColumnHeaders = {"school id","year", "name", "address id", "street", "village", "zip", "district", "region", "footprint"};
    private boolean isYearRangeSelected = false;

    public NextITDemoGUI(String title){
        super(title);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setContentPane(tabbedPaneMain);
        appCore = new AppCore();
        this.pack();
        menuPanel.setVisible(false);
        showAllRecords();
        ButtonCreateRecord.setEnabled(false);
        ButtonRefreshRecords.setEnabled(false);
        ButtonUpdateRecord.setEnabled(false);
        ButtonDeleteRecord.setEnabled(false);
        ButtonLogOut.setVisible(false);
        ButtonLogin.setVisible(true);

        JLabelLogin.setVisible(true);
        JFieldLogin.setVisible(true);
        JLabelPass.setVisible(true);
        JPassFieldInput.setVisible(true);
        loadJSONFileButton.setEnabled(false);
        exportToCSVFileButton.setEnabled(false);
        SpinnerFrom.setValue(2000);
        SpinnerTo.setValue(2100);


        ButtonLogin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userName = null;
                userId = 0;
                credentials = 0;
                appCore = new AppCore();
                String tempUserName = JFieldLogin.getText();
                char[] passInput = JPassFieldInput.getPassword();
                User tempUser = appCore.getUser(tempUserName, passInput);
                if(tempUser.getUserName() != null){
                    userName = tempUser.getUserName();
                    userId = tempUser.getUserID();
                    credentials = tempUser.getCredentials();
                    if(credentials == 1){
                        JLabelLoginStatus.setText(userName + " (admin)");
                    }else {
                        JLabelLoginStatus.setText(userName + " (visitor)");
                    }
                    ButtonLogOut.setVisible(true);
                    ButtonLogin.setVisible(false);
                    menuPanel.setVisible(true);
                    loginPanel.setVisible(false);
                    ButtonCreateRecord.setEnabled(true);
                    ButtonRefreshRecords.setEnabled(true);
                    ButtonUpdateRecord.setEnabled(true);
                    ButtonDeleteRecord.setEnabled(true);
                    JLabelLogin.setVisible(false);
                    JFieldLogin.setVisible(false);
                    JLabelPass.setVisible(false);
                    JPassFieldInput.setVisible(false);
                    loadJSONFileButton.setEnabled(true);
                    exportToCSVFileButton.setEnabled(true);

                }
            }
        });

        loadJSONFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser fileChooser = new JFileChooser();
                fileChooser.setCurrentDirectory(new File(System.getProperty("user.home")));
                FileNameExtensionFilter filter = new FileNameExtensionFilter("*.json", "json");
                fileChooser.setFileFilter(filter);
                int result = fileChooser.showOpenDialog(null);
                if (result == JFileChooser.APPROVE_OPTION) {
                    File selectedFile = fileChooser.getSelectedFile();

                    appCore.checkJSONInput(selectedFile.getAbsolutePath());
                    showAllRecords();
                    ArrayList<Address> badZipAddresses = appCore.getWrongZipRecords();
                    TextAreaInfo.setText("Database contains " + badZipAddresses.size() +
                            " of address records with wrong format of ZIP value!");
                }
            }
        });

        exportToCSVFileButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JFileChooser jc = new JFileChooser();
                jc.setDialogTitle("Choose file path to export.");
                int result = jc.showSaveDialog(null);
                if(result == JFileChooser.APPROVE_OPTION){
                    File fileToSave = jc.getSelectedFile();
                    System.out.println(fileToSave.getAbsolutePath());
                    if(appCore.exportToCSVFile(fileToSave.getAbsolutePath())){
                        TextAreaInfo.setText("CSV file: \t" + fileToSave.getAbsolutePath() + ".csv \twas successfully created.");
                    }
                }
            }
        });


        JTableAllRecords.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                textFieldSchoolID.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 0).toString());
                JTextFieldYear.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 1).toString());
                JTextFieldName.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 2).toString());
                JTextFieldAddressID.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 3).toString());
                JTextFieldStreet.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 4).toString());
                JTextFieldVillage.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 5).toString());
                JTextFieldZIP.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 6).toString());
                JTextFieldDistrict.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 7).toString());
                JTextFieldRegion.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 8).toString());
                JTextFieldFootprint.setText(JTableAllRecords.getValueAt(JTableAllRecords.getSelectedRow(), 9).toString());
            }
        });
        ButtonDeleteRecord.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tempInfoText = "";
                try{
                    appCore.deleteAddress(Integer.parseInt(JTextFieldAddressID.getText()));
                    tempInfoText = "Address with ID: \t" + JTextFieldAddressID.getText() + " \twas successfully removed from database.\n";

                }catch(Exception ex){
                    tempInfoText = "Unable to delete address\t"+ JTextFieldAddressID.getText() + ", please check correct format. \t" + ex.toString() + "\n";
                }

                try{
                    appCore.deleteSchool(Integer.parseInt(textFieldSchoolID.getText()));
                    tempInfoText = tempInfoText + "School with ID: \t" + textFieldSchoolID.getText() + " \twas successfully removed from database.\n";
                }catch(Exception ex){
                    tempInfoText = tempInfoText + "Unable to delete address \t"+ JTextFieldAddressID.getText() + ", please check correct format. \t" + ex.toString() + "\n";
                }
                showAllRecords();
                clearModFields();
                TextAreaInfo.setText(tempInfoText);
            }
        });
        ButtonRefreshRecords.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(comboBoxYears.getSelectedIndex() == 0) {
                    showAllRecords();
                    isYearRangeSelected = false;
                }else{
                    int startYear = (Integer) SpinnerFrom.getValue();
                    int endYear = (Integer) SpinnerTo.getValue();
                    isYearRangeSelected = true;
                    appCore.showAllRecordsByYearRange(startYear, endYear);
                }


                clearModFields();
            }
        });
        ButtonLogOut.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                userName = null;
                userId = 0;
                credentials = 0;
                ButtonLogOut.setVisible(false);
                ButtonLogin.setVisible(true);

                ButtonCreateRecord.setEnabled(false);
                ButtonRefreshRecords.setEnabled(false);
                ButtonUpdateRecord.setEnabled(false);
                ButtonDeleteRecord.setEnabled(false);
                JLabelLoginStatus.setText("Visitor");
                JLabelLogin.setVisible(true);
                JFieldLogin.setVisible(true);
                JLabelPass.setVisible(true);
                JPassFieldInput.setVisible(true);
                loadJSONFileButton.setEnabled(false);
                exportToCSVFileButton.setEnabled(false);
                JFieldLogin.setText("");
                JPassFieldInput.setText("");
            }
        });
        ButtonCreateRecord.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //int address_id, School school, String street, String village, String zip
                String tempInfoText = "";
                try{
                    int school_id = Integer.parseInt(textFieldSchoolID.getText());
                    short year = (short) Integer.parseInt(JTextFieldYear.getText());
                    String name = JTextFieldName.getText();
                    String district = JTextFieldDistrict.getText();
                    String region = JTextFieldRegion.getText();
                    BigDecimal footprint = new BigDecimal(JTextFieldFootprint.getText());
                    int address_id = getRandomId();
                    if(JTextFieldAddressID.getText().length() > 0){
                        if(Integer.parseInt(JTextFieldAddressID.getText()) >= 0){
                            address_id = Integer.parseInt(JTextFieldAddressID.getText());
                        }
                    }
                    String street = JTextFieldStreet.getText();
                    String village = JTextFieldVillage.getText();
                    String zip = JTextFieldZIP.getText();

                    if(zip.length() == 5){
                        School tempFilledSchool = new School(school_id, year, name, district, region, footprint);
                        Address tempAddress = new Address(address_id, tempFilledSchool, street, village, zip);
                        boolean isCreated = appCore.createNewAddressSchool(tempAddress);
                        if (isCreated){
                            tempInfoText = "Record was successfully created.\nCreated address ID: \t" + address_id + " \nCreated school ID: \t" + school_id;
                        }else {
                            tempInfoText = "Input format error. Please check filled values.\n";
                        }
                        clearModFields();
                    }else {
                        tempInfoText = "ZIP code is in wrong format. It must consists of 5 numbers.";
                    }
                }catch (Exception ex){
                    System.out.println(ex);
                }
                TextAreaInfo.setText(tempInfoText);
                showAllRecords();
            }
        });
        ButtonUpdateRecord.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String tempInfoText = "";
                if(JTextFieldAddressID.getText().length() > 0){
                    if(Integer.parseInt(JTextFieldAddressID.getText()) >= 0){
                        int address_id = Integer.parseInt(JTextFieldAddressID.getText());
                        String zip = JTextFieldZIP.getText();
                        if(zip.length() == 5) {
                            try {
                                Address tempAddress = appCore.getAddressByID(address_id);

                                int school_id = Integer.parseInt(textFieldSchoolID.getText());
                                short year = (short) Integer.parseInt(JTextFieldYear.getText());
                                String name = JTextFieldName.getText();
                                String district = JTextFieldDistrict.getText();
                                String region = JTextFieldRegion.getText();
                                BigDecimal footprint = new BigDecimal(JTextFieldFootprint.getText());
                                String street = JTextFieldStreet.getText();
                                String village = JTextFieldVillage.getText();

                                School tempFilledSchool = new School(school_id, year, name, district, region, footprint);
                                boolean isCreatedFileCorrectly = false;
                                if(appCore.updateSchoolByID(tempAddress.getSchool().getId(), tempFilledSchool)){
                                    isCreatedFileCorrectly = true;
                                }else{
                                    tempInfoText = "There was problem with adding school record. Please check address ID.";
                                }
                                if(isCreatedFileCorrectly){
                                    Address tempNewAddress = new Address(address_id, tempFilledSchool, street, village, zip);
                                    appCore.updateAddressByID(address_id, tempNewAddress);
                                    tempInfoText = "Record of address with address ID: \t" + address_id +
                                            " \t and school ID: \t" + tempNewAddress.getSchool().getId() +
                                            " \t was successfully modified.";
                                    clearModFields();
                                }else{
                                    tempInfoText = "New record of address and school was added successfully.";
                                }
                            }catch(Exception ex){
                                System.out.println(ex);
                                tempInfoText = "Address or school to update were not found.";
                            }
                        }else {
                            tempInfoText = "ZIP code is in wrong format. It must consists of 5 numbers.";
                        }
                    }
                }
                TextAreaInfo.setText(tempInfoText);
                showAllRecords();
            }
        });
    }

    private int getRandomId(){
        int max = Integer.MAX_VALUE;
        Random rand = new Random();
        return rand.nextInt(max) ;
    }

    public void showAllRecords(){
        DefaultTableModel tempTableModelReport = (DefaultTableModel) JTableAllRecords.getModel();
        tempTableModelReport.setRowCount(0);
        tempTableModelReport.setColumnIdentifiers(tableColumnHeaders);
        String[][] tableData = null;

        if(comboBoxYears.getSelectedIndex() == 1){
            int startYear = (Integer) SpinnerFrom.getValue();
            int endYear = (Integer) SpinnerTo.getValue();
            tableData = appCore.showAllRecordsByYearRange(startYear, endYear);
        }else{
            tableData = appCore.getAllAddressesTable();
        }

        for(int tempRecordPointer = 0; tempRecordPointer < tableData.length; tempRecordPointer++){
            tempTableModelReport.addRow(tableData[tempRecordPointer]);
        }
        JLabelRows.setText("Rows:  " + tableData.length);
    }

    public void clearModFields(){
        textFieldSchoolID.setText("");
        JTextFieldYear.setText("");
        JTextFieldName.setText("");
        JTextFieldAddressID.setText("");
        JTextFieldStreet.setText("");
        JTextFieldVillage.setText("");
        JTextFieldZIP.setText("");
        JTextFieldDistrict.setText("");
        JTextFieldRegion.setText("");
        JTextFieldFootprint.setText("");
    }

    public static void main(String[] args) {
        JFrame frame = new NextITDemoGUI("NextITDemo");
        frame.setVisible(true);
    }

    private void createUIComponents() {
        // TODO: place custom component creation code here
    }
}
