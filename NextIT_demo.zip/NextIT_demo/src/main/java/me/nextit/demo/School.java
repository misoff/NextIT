package me.nextit.demo;

import java.math.BigDecimal;

public class School {

    private int id;
    private short year;
    private String name;
    private String district;
    private String region;
    private BigDecimal footprint;

    public School(){


    }

    public School(int id, short year, String name, String district, String region, BigDecimal footprint){
        this.id = id;
        this.year = year;
        this.name = name;
        this.district = district;
        this.region = region;
        this.footprint = footprint;
    }

    public School(int id, short year, String name, String district, String region, String footprint){
        this.id = id;
        this.year = year;
        this.name = name;
        this.district = district;
        this.region = region;
        this.footprint = new BigDecimal(footprint);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public short getYear() {
        return year;
    }

    public void setYear(short year) {
        this.year = year;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public BigDecimal getFootprint() {
        return footprint;
    }

    public void setFootprint(BigDecimal footprint) {
        this.footprint = footprint;
    }

}
