package me.nextit.demo;

public class Address {

    private int id;
    private School school;
    private String street;
    private String village;
    private String zip;

    public Address(int id, School school, String street, String village, String zip){
        this.id = id;
        this.school = school;
        this.street = street;
        this.village = village;
        this.zip = zip;
    }

    public Address(){

    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public School getSchool() {
        return school;
    }

    public void setSchool(School school) {
        this.school = school;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getVillage() {
        return village;
    }

    public void setVillage(String village) {
        this.village = village;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }
}
