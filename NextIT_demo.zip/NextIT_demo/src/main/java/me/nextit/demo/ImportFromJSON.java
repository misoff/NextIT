package me.nextit.demo;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.Random;
import java.util.*;

public class ImportFromJSON {

    public ImportFromJSON(){
    }

    public boolean checkFilePath(String tempPath){
        File f = new File(tempPath);
        return f.exists();
    }

    public ArrayList<Address> insertJSONFile(String tempPath){
        //tempPath = "C:\\Users\\Michal\\IdeaProjects\\NextIT\\src\\data.json";
        System.out.println(tempPath);
        ArrayList<Address> allAddressList = new ArrayList<>();
        //File f = new File(tempPath);
        JSONParser parser = new JSONParser();

        try{
            Object obj = parser.parse( new FileReader(tempPath));
            JSONObject jsonObject = (JSONObject) obj;
            HashMap<String, Object> allRecordsMap = (HashMap) jsonObject;
            ArrayList<String> tempYearsList = new ArrayList<>(allRecordsMap.keySet());

            for(int tempYearPointer = 0; tempYearPointer < tempYearsList.size(); tempYearPointer++){
                HashMap<String, Object> tempSchoolRecordsMap = (HashMap) allRecordsMap.get(tempYearsList.get(tempYearPointer));
                ArrayList<String> tempSchoolIDs = new ArrayList<>(tempSchoolRecordsMap.keySet());
                for(int tempSchoolPointer = 0; tempSchoolPointer < tempSchoolIDs.size(); tempSchoolPointer++){
                    HashMap<String, Object> tempSchoolInfoMap = (HashMap) tempSchoolRecordsMap.get(tempSchoolIDs.get(tempSchoolPointer));
                    HashMap<String, Object> tempAddressInfoMap = (HashMap) tempSchoolInfoMap.get("address");
                    School tempSchool = new School(
                            Integer.parseInt(tempSchoolIDs.get(tempSchoolPointer)),
                            Short.parseShort(tempYearsList.get(tempYearPointer).substring(0, 4)),
                            tempSchoolInfoMap.get("name").toString(),
                            tempSchoolInfoMap.get("district").toString(),
                            tempSchoolInfoMap.get("region").toString(),
                            new BigDecimal(tempSchoolInfoMap.get("footprint").toString())
                    );
                    int tempAddressID = getRandomId();
                    String tempStreet = null;
                    try {
                        tempStreet = tempAddressInfoMap.get("street").toString();
                    }catch(NullPointerException npe){
                        System.out.println(npe);
                    }

                    String tempVillage = null;
                    try {
                        tempVillage = tempAddressInfoMap.get("village").toString();
                    }catch(NullPointerException npe){
                    }

                    String tempZip = null;
                    try {
                        tempZip = tempAddressInfoMap.get("zip").toString();
                        tempZip = checkZipLength(tempZip);
                    }catch(NullPointerException npe){
                    }

                    Address tempAddress = new Address(
                            tempAddressID,
                            tempSchool,
                            tempStreet,
                            tempVillage,
                            tempZip
                    );
                    allAddressList.add(tempAddress);
                }
            }
        }catch(IOException | ParseException pe){
            System.out.println(pe);
        }
        return allAddressList;
    }



    private String checkZipLength(String tempZip){
        if(tempZip.length() == 5){
            return tempZip;
        }else if(tempZip.length() <= 5){
            //System.out.println("ZIP:\t" + tempZip + "\t error!");
            return tempZip + "X";
        }else {
            return "X" + tempZip.substring(0,4);
        }
    }

    private int getRandomId(){
        int max = Integer.MAX_VALUE;
        Random rand = new Random();
        return rand.nextInt(max) ;
    }
}
