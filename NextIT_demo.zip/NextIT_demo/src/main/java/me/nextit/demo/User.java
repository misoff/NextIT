package me.nextit.demo;

public class User {

    private String userName;
    private int userID;
    private int credentials;

    public User(){

    }

    public User(String userName, int userID, int credentials){
        this.userName = userName;
        this.userID = userID;
        this.credentials = credentials;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public int getCredentials() {
        return credentials;
    }

    public void setCredentials(int credentials) {
        this.credentials = credentials;
    }
}
