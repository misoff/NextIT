package me.nextit.demo;

import java.util.ArrayList;

public class AppCore {
    private DBConnection dbConnection;
    public AppCore(){
        dbConnection = new DBConnection();

    }

    public void checkJSONInput(String tempPath){
        ImportFromJSON inputReader = new ImportFromJSON();
        //String tempPath = "C:\\Users\\Michal\\IdeaProjects\\NextIT_demo\\src\\main\\java\\data.json";
        if (inputReader.checkFilePath(tempPath)) {
            inputReader.insertJSONFile(tempPath);
            addAllRecordsIntoDB(inputReader.insertJSONFile(tempPath));
            //return true;
        }else {
            System.out.println("Unable to load json file");
            //return false;
        }

    }

    public void addAllRecordsIntoDB(ArrayList<Address> allAddressList){
        for( int tempRecordPointer = 0; tempRecordPointer < allAddressList.size(); tempRecordPointer++){
            dbConnection.addAddressSchool(allAddressList.get(tempRecordPointer));
        }
    }

    public ArrayList<Address> getAllAddresses(){
         return dbConnection.getAllAddressesAndSchools();
    }

    public String[][] getAllAddressesTable(){
        return fillTable(dbConnection.getAllAddressesAndSchools());
    }

    public String[][] showAllRecordsByYearRange(int start, int end){
        return fillTable(dbConnection.getAllAddressesAndSchoolsByYears(true, start, end));
    }

    private String[][] fillTable(ArrayList<Address> tempAddresses){
        String[][] tempTable = new String[tempAddresses.size()][10];
        for(int tempRecordPointer = 0; tempRecordPointer < tempAddresses.size(); tempRecordPointer++){
            tempTable[tempRecordPointer][0] = tempAddresses.get(tempRecordPointer).getSchool().getId() + "";
            tempTable[tempRecordPointer][1] = tempAddresses.get(tempRecordPointer).getSchool().getYear() + "";
            tempTable[tempRecordPointer][2] = tempAddresses.get(tempRecordPointer).getSchool().getName();
            tempTable[tempRecordPointer][3] = tempAddresses.get(tempRecordPointer).getId() + "";
            tempTable[tempRecordPointer][4] = tempAddresses.get(tempRecordPointer).getStreet();
            tempTable[tempRecordPointer][5] = tempAddresses.get(tempRecordPointer).getVillage();
            tempTable[tempRecordPointer][6] = tempAddresses.get(tempRecordPointer).getZip();
            tempTable[tempRecordPointer][7] = tempAddresses.get(tempRecordPointer).getSchool().getDistrict();
            tempTable[tempRecordPointer][8] = tempAddresses.get(tempRecordPointer).getSchool().getRegion();
            tempTable[tempRecordPointer][9] = tempAddresses.get(tempRecordPointer).getSchool().getFootprint() + "";
        }
        return tempTable;
    }

    public User getUser(String userName, char[] passInput){
        return dbConnection.getUser( userName, passInput);
    }

    public boolean deleteAddress(int addressID){
        return dbConnection.deleteAddressByID(addressID);
    }

    public boolean deleteSchool(int schoolID){
        return dbConnection.deleteSchoolByID(schoolID);
    }

    public boolean exportToCSVFile(String tempPath){
        ExportToCSV exportToCSV = new ExportToCSV();
        return exportToCSV.execLocalExport(tempPath, dbConnection.getAllAddressesAndSchools());
    }

    public boolean createNewSchool(School tempSchool){
        return dbConnection.addSchool(tempSchool);
    }

    public boolean createNewAddress(Address tempAddress){
        return dbConnection.addAddress(tempAddress);
    }

    public boolean createNewAddressSchool(Address tempAddress){
        return dbConnection.addAddressSchool(tempAddress);
    }

    public Address getAddressByID(int tempID){
        return dbConnection.getAddressByID(tempID);
    }

    public boolean updateSchoolByID(int tempID, School tempSchool){
        return dbConnection.updateSchool( tempID, tempSchool);
    }

    public boolean updateAddressByID(int tempID, Address tempAddress){
        return dbConnection.updateAddress( tempID, tempAddress);
    }

    public ArrayList<Address> getWrongZipRecords(){
        return dbConnection.getAllAddressesAndSchoolsWithWrongZip();
    }
}
